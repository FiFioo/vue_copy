# cloud_music

#### 预览

![发现页面](./imgs/find_page.png)

####  安装依赖
```
npm install
```

#### 启动
```
npm run serve
```

