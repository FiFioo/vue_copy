<template>
    <div>
        <p>朋友</p>
    </div>
</template>