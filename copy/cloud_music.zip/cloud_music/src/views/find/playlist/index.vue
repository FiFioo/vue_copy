<template>
    <Playlist />
</template>

<script>
import Playlist from "./components/Playlist";
export default {
    components: {
        Playlist
    }
}
</script>