<template>
    <router-view>
        <!-- <router-link :to=""></router-link> -->
    </router-view>
</template>

<script>
export default {
    
}
</script>